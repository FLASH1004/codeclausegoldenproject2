import Levenshtein

def read_file_content(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def plagiarism_check(file1_content, file2_content):
    similarity_ratio = Levenshtein.ratio(file1_content, file2_content)
    return similarity_ratio

def main():
    print("Plagiarism Check")
    print("----------------")

    file1_path = input("Enter the path of the first file: ")
    file2_path = input("Enter the path of the second file: ")

    try:
        file1_content = read_file_content(file1_path)
        file2_content = read_file_content(file2_path)

        similarity_ratio = plagiarism_check(file1_content, file2_content)
        print(f"Similarity Ratio: {similarity_ratio:.2%}")

    except FileNotFoundError:
        print("File not found. Please check the file paths and try again.")

if __name__ == "__main__":
    main()
